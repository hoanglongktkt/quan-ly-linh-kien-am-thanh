import React, { useState, useEffect, useRef } from 'react';
import { Product, Expense, Order, ChannelSettings, SyncLog, Supplier, ImportTransaction, BulkUpdatePayload, BulkSaveProductUpdate, ConnectedShop } from './types';
import { 
  INITIAL_SYNC_LOGS,
} from './data';
import Dashboard from './components/Dashboard';
import ProductList from './components/ProductList';
import InventoryAudit from './components/InventoryAudit';
import BulkEditor from './components/BulkEditor';
import Financials from './components/Financials';
import SettingsView from './components/Settings';
import SupplierManager from './components/SupplierManager';
import ImportManager from './components/ImportManager';
import OrderManager from './components/OrderManager';
import OrderPicking from './components/OrderPicking';
import PublishManager from './components/PublishManager';
import LoginPage from './components/LoginPage';
import ErrorBoundary from './components/ErrorBoundary';
import BrandLogo, { BrandHeader } from './components/BrandLogo';
import NewOrderAlertButton from './components/NewOrderAlert';
import { APP_TITLE } from './config/brand';
import { CATALOG_PURGE_FLAG, purgeLegacyCatalogCache } from './utils/catalogStorage';
import { sanitizeOrders } from './utils/sanitizeOrder';
import { safeGetItem, safeGetJson, safeRemoveItem, safeSetItem } from './utils/safeStorage';
import { parseJsonResponse } from './utils/apiClient';
import { clearLegacyOrdersLocalStorage, loadOrdersCache, saveOrdersCache } from './utils/orderCache';
import { 
  LayoutDashboard, 
  Package, 
  Sparkles, 
  Coins, 
  Settings, 
  HelpCircle,
  RefreshCw,
  ShoppingBag,
  Users,
  ArrowDownToLine,
  ClipboardList,
  Globe,
  LogOut,
  Barcode,
  Menu,
  X,
  ScanLine,
  ShoppingBasket,
  Scale,
} from 'lucide-react';

function resolveTabFromPath(): string {
  if (typeof window === 'undefined') return 'dashboard';
  const path = window.location.pathname.replace(/\/$/, '') || '/';
  if (path === '/picking') return 'picking';
  return 'dashboard';
}

const DEMO_SHOP_INTERNAL_IDS = new Set(['shop-shopee-1', 'shop-shopee-2', 'shop-tiktok-1', 'shop-woo-1']);

/** Chỉ lọc shop seed demo cũ — không lọc theo shopId thật (VD: 4127421). */
function stripLegacyDemoShops(shops: ConnectedShop[] = []) {
  return shops.filter((s) => {
    if (DEMO_SHOP_INTERNAL_IDS.has(s.id)) return false;
    if (s.shopName === 'LTAT' || s.shopName.includes('thongtinsolutions')) return false;
    if (s.wooUrl?.includes('thongtinsolutions.com')) return false;
    if (s.apiKey?.includes('demo')) return false;
    return true;
  });
}

function mergeChannelSettings(raw: Partial<ChannelSettings> | null | undefined): ChannelSettings {
  return {
    ...emptyChannelSettings(),
    ...raw,
    shops: Array.isArray(raw?.shops) ? raw.shops : [],
  };
}

function emptyChannelSettings(): ChannelSettings {
  return {
    shopeeConnected: false,
    shopeeShopId: '',
    shopeeApiKey: '',
    tiktokConnected: false,
    tiktokShopId: '',
    tiktokApiKey: '',
    shops: [],
  };
}

function mergeShopLists(primary: ConnectedShop[] = [], secondary: ConnectedShop[] = []): ConnectedShop[] {
  const map = new Map<string, ConnectedShop>();
  for (const s of primary) {
    map.set(`${s.platform}:${String(s.shopId)}`, s);
  }
  for (const s of secondary) {
    const key = `${s.platform}:${String(s.shopId)}`;
    if (!map.has(key)) map.set(key, s);
  }
  return [...map.values()];
}

export default function App() {
  // Authentication States
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [adminUser, setAdminUser] = useState<string>('');
  const [authChecking, setAuthChecking] = useState<boolean>(true);

  // 1. Initialize State with Local Storage fallback
  const [products, setProducts] = useState<Product[]>([]);

  const [expenses, setExpenses] = useState<Expense[]>([]);

  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState<boolean>(false);
  const [productsLoading, setProductsLoading] = useState<boolean>(false);

  const [logs, setLogs] = useState<SyncLog[]>(() =>
    safeGetJson('omni_logs', INITIAL_SYNC_LOGS),
  );

  const [settings, setSettings] = useState<ChannelSettings>(() => {
    const saved = safeGetJson<ChannelSettings | null>('omni_settings', null);
    if (!saved) return emptyChannelSettings();
    try {
      return mergeChannelSettings({
        ...saved,
        shops: stripLegacyDemoShops(saved.shops ?? []),
      });
    } catch {
      return emptyChannelSettings();
    }
  });

  const channelSettingsFetchRef = useRef<AbortController | null>(null);
  const channelSettingsSaveAtRef = useRef(0);

  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  const [imports, setImports] = useState<ImportTransaction[]>([]);

  const [highlightProductId, setHighlightProductId] = useState<string | null>(null);
  const [importPrefillProductId, setImportPrefillProductId] = useState<string | null>(null);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState(() => resolveTabFromPath());
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [focusScanner, setFocusScanner] = useState<boolean>(false);
  
  // Selected products for bulk editing
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  useEffect(() => {
    const onPopState = () => {
      setActiveTab(resolveTabFromPath());
      setFocusScanner(false);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  // Đơn hàng: RAM (React state) + IndexedDB cache — không dùng localStorage.
  useEffect(() => {
    clearLegacyOrdersLocalStorage();
  }, []);

  useEffect(() => {
    const trimmed = logs.length > 200 ? logs.slice(-200) : logs;
    safeSetItem('omni_logs', JSON.stringify(trimmed));
  }, [logs]);

  useEffect(() => {
    safeSetItem('omni_settings', JSON.stringify(settings));
  }, [settings]);

  // Token Verification on Mount
  useEffect(() => {
    const verifyToken = async () => {
      const token = localStorage.getItem('admin_token');
      if (!token) {
        setIsAuthenticated(false);
        setAuthChecking(false);
        return;
      }

      try {
        const response = await fetch('/api/auth/verify', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setIsAuthenticated(true);
          setAdminUser(data.username);
        } else {
          safeRemoveItem('admin_token');
          setIsAuthenticated(false);
        }
      } catch (err) {
        console.error("Auth verification error:", err);
        safeRemoveItem('admin_token');
        setIsAuthenticated(false);
      } finally {
        setAuthChecking(false);
      }
    };

    verifyToken();
  }, []);

  // Fetch the real, backend-synced order list (Shopee webhook data) once authenticated.
  const fetchOrders = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;

    setOrdersLoading(true);
    try {
      const response = await fetch('/api/orders', {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (response.ok) {
        const data: Order[] = await response.json();
        const sanitized = sanitizeOrders(data);
        setOrders(sanitized);
        void saveOrdersCache(sanitized);
      }
    } catch (err) {
      console.error("Fetch orders error:", err);
    } finally {
      setOrdersLoading(false);
    }
  };

  useEffect(() => {
    purgeLegacyCatalogCache();
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const linked = params.get('shopee_linked');
    const oauthShopId = String(params.get('shop_id') || '').trim();
    const expectedShop = String(params.get('expected_shop') || '').trim();
    const savedShops = String(params.get('saved_shops') || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (linked === '0') {
      const err = params.get('error') || 'OAuth thất bại';
      alert(decodeURIComponent(err));
      window.history.replaceState({}, '', window.location.pathname + window.location.hash);
      return;
    }

    if (linked !== '1' || !oauthShopId) return;

    if (expectedShop && expectedShop !== oauthShopId) {
      alert(
        `Cảnh báo: Bạn yêu cầu OAuth shop ${expectedShop} nhưng Shopee trả về shop ${oauthShopId}.\n` +
          'Token đã lưu trên máy chủ — hãy kiểm tra Shop ID trong Cài đặt có khớp không.',
      );
      window.history.replaceState({}, '', window.location.pathname + window.location.hash);
      return;
    }

    alert(`OAuth Shopee thành công. Shop ID: ${oauthShopId}${savedShops.length ? ` (đã lưu: ${savedShops.join(', ')})` : ''}`);
    window.history.replaceState({}, '', window.location.pathname + window.location.hash);
  }, []);

  const apiAuthHeaders = (): Record<string, string> => {
    const token = localStorage.getItem('admin_token');
    return {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  };

  const persistChannelSettings = async (next: ChannelSettings): Promise<boolean> => {
    const token = localStorage.getItem('admin_token');
    if (!token) return false;
    channelSettingsFetchRef.current?.abort();
    const expectedShopIds = (next.shops ?? []).map((s) => String(s.shopId));
    try {
      const response = await fetch('/api/settings/channels', {
        method: 'PUT',
        headers: apiAuthHeaders(),
        body: JSON.stringify({ settings: next }),
      });
      const data = await parseJsonResponse<{ settings?: ChannelSettings; message?: string; error?: string; shopCount?: number }>(response);
      if (response.ok && data?.settings) {
        const merged = mergeChannelSettings(data.settings);
        const returnedIds = (merged.shops ?? []).map((s) => String(s.shopId));
        const missing = expectedShopIds.filter((id) => !returnedIds.includes(id));
        if (missing.length > 0) {
          console.error('[Channel Settings] Server thiếu shop sau khi lưu:', missing);
          return false;
        }
        channelSettingsSaveAtRef.current = Date.now();
        setSettings(merged);
        return true;
      }
      console.error('[Channel Settings] PUT failed:', data?.error || data?.message);
      return false;
    } catch (err) {
      console.error('[Channel Settings] PUT error:', err);
      return false;
    }
  };

  const fetchChannelSettings = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;
    channelSettingsFetchRef.current?.abort();
    const controller = new AbortController();
    channelSettingsFetchRef.current = controller;
    const fetchStartedAt = Date.now();
    try {
      const response = await fetch('/api/settings/channels', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
        signal: controller.signal,
      });
      if (controller.signal.aborted) return;
      if (channelSettingsSaveAtRef.current > fetchStartedAt) return;
      if (!response.ok) return;
      const data = await parseJsonResponse<{ settings?: ChannelSettings }>(response);
      if (controller.signal.aborted) return;
      if (channelSettingsSaveAtRef.current > fetchStartedAt) return;

      const serverMerged = mergeChannelSettings(data.settings);
      setSettings((prev) => ({
        ...serverMerged,
        shops: mergeShopLists(serverMerged.shops ?? [], prev.shops ?? []),
      }));

      const local = safeGetJson<ChannelSettings | null>('omni_settings', null);
      const localShops = stripLegacyDemoShops(local?.shops ?? []);
      if ((serverMerged.shops ?? []).length === 0 && localShops.length > 0) {
        await persistChannelSettings(mergeChannelSettings({ ...local, shops: localShops }));
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      console.error('Fetch channel settings error:', err);
    }
  };

  const fetchProducts = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;

    setProductsLoading(true);
    try {
      const response = await fetch('/api/products', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) return;

      const data: Product[] = await response.json();
      if (Array.isArray(data)) {
        setProducts(data);
      }
    } catch (err) {
      console.error('Fetch products error:', err);
    } finally {
      setProductsLoading(false);
    }
  };

  const formatPullErrors = (errors: any[]): string =>
    errors
      .map((e) => {
        const shop = e.shopId ? `Shop ${e.shopId}` : 'Hệ thống';
        const code = e.error ? ` [${e.error}]` : '';
        const msg = e.message || e.error || 'Lỗi không xác định';
        return `${shop}${code}: ${msg}`;
      })
      .join('; ');

  const extractApiErrorMessage = (data: Record<string, unknown>, fallback: string): string => {
    const parts = [data?.message, data?.error, data?.detail, data?.hint, data?.causeMessage].filter(Boolean);
    return parts.map(String).join(' — ') || fallback;
  };

  // Actively pull real orders straight from Shopee (v2.order.get_order_list +
  // get_order_detail) via the backend, then refresh local state with the result.
  // Bound to the "Cập nhật đơn hàng" button.
  const pullOrders = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;

    setOrdersLoading(true);
    try {
      const response = await fetch('/api/orders/pull', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(extractApiErrorMessage(data, 'Kéo đơn hàng thất bại.'));
      }
      const pulled = Number(data.pulled) || 0;
      const pullErrors = Array.isArray(data.errors) ? data.errors : [];
      if (pullErrors.length > 0 && pulled === 0) {
        throw new Error(formatPullErrors(pullErrors));
      }
      const refreshRes = await fetch('/api/orders', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (refreshRes.ok) {
        const freshOrders = await refreshRes.json();
        if (Array.isArray(freshOrders)) {
          const sanitized = sanitizeOrders(freshOrders);
          setOrders(sanitized);
          void saveOrdersCache(sanitized);
        }
      } else if (Array.isArray(data.orders) && data.orders.length > 0) {
        const sanitized = sanitizeOrders(data.orders);
        setOrders(sanitized);
        void saveOrdersCache(sanitized);
      }
      if (data.warning) {
        throw new Error(String(data.warning));
      }
      if (pullErrors.length > 0) {
        console.warn('[Orders Pull] partial errors:', formatPullErrors(pullErrors));
      }
    } finally {
      setOrdersLoading(false);
    }
  };

  // Persist status/tracking changes made in the UI back to the real orders database.
  const handleUpdateOrders = (updatedOrders: Order[]) => {
    const sanitized = sanitizeOrders(updatedOrders);
    const previousById = new Map(orders.map(o => [o.id, o]));
    setOrders(sanitized);
    void saveOrdersCache(sanitized);

    const token = localStorage.getItem('admin_token');
    if (!token) return;

    sanitized.forEach(order => {
      const prev = previousById.get(order.id);
      if (!prev || JSON.stringify(prev) === JSON.stringify(order)) return;

      fetch(`/api/orders/${encodeURIComponent(order.id)}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(order),
      }).catch(err => console.error(`Sync order ${order.id} error:`, err));
    });
  };

  const handleLoginSuccess = (token: string, username: string) => {
    safeSetItem('admin_token', token);
    setIsAuthenticated(true);
    setAdminUser(username);
  };

  const handleLogout = () => {
    safeRemoveItem('admin_token');
    setIsAuthenticated(false);
    setAdminUser('');
    setActiveTab('dashboard');
    setFocusScanner(false);
  };

  // 3. Actions handlers
  const handleAddProduct = async (prod: Product) => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      try {
        const response = await fetch('/api/products', {
          method: 'POST',
          headers: apiAuthHeaders(),
          body: JSON.stringify(prod),
        });
        if (response.ok) {
          const saved = await response.json();
          setProducts(prev => [saved, ...prev]);
          prod = saved;
        } else {
          setProducts(prev => [prod, ...prev]);
        }
      } catch {
        setProducts(prev => [prod, ...prev]);
      }
    } else {
      setProducts(prev => [prod, ...prev]);
    }

    const channelsLabel = prod.channels.map(c => c.toUpperCase()).join(' & ') || 'Hệ thống nội bộ';
    handleAddLog({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      channel: prod.channels.length > 0 ? prod.channels[0] : 'all',
      type: 'publish',
      status: 'success',
      message: `Đã khởi tạo và đăng thành công sản phẩm mới [${prod.title}] lên ${channelsLabel}`
    });
  };

  const handleUpdateProduct = async (updated: Product, opts?: { save?: boolean }) => {
    setProducts(prev => prev.map(p => p.id === updated.id ? updated : p));
    if (!opts?.save) return;

    const token = localStorage.getItem('admin_token');
    if (!token) return;

    try {
      const response = await fetch(`/api/products/${encodeURIComponent(updated.id)}`, {
        method: 'PATCH',
        headers: apiAuthHeaders(),
        body: JSON.stringify({
          title: updated.title,
          sku: updated.sku,
          barcode: updated.barcode,
          stock: updated.stock,
          sellingPrice: updated.sellingPrice,
          wholesalePrice: updated.wholesalePrice,
          importPrice: updated.importPrice,
          weight: updated.weight,
          unit: updated.unit,
          status: updated.status,
          channels: updated.channels,
          shopeeId: updated.shopeeId,
          shopeeItemId: updated.shopeeItemId,
          shopeeModelId: updated.shopeeModelId,
          tiktokId: updated.tiktokId,
          wooId: updated.wooId,
        }),
      });
      if (response.ok) {
        const saved = await response.json();
        setProducts(prev => prev.map(p => p.id === saved.id ? saved : p));
      }
    } catch (err) {
      console.error('Update product error:', err);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Bạn có chắc chắn muốn xóa sản phẩm này khỏi hệ thống quản lý?')) return;

    const token = localStorage.getItem('admin_token');
    if (token) {
      try {
        await fetch(`/api/products/${encodeURIComponent(id)}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch (err) {
        console.error('Delete product error:', err);
      }
    }
    setProducts(prev => prev.filter(p => p.id !== id));
    setSelectedIds(prev => prev.filter(item => item !== id));
  };

  const handleUpdateBulk = (updatedProducts: Product[]) => {
    setProducts(prev => {
      const map = new Map(prev.map(p => [p.id, p]));
      updatedProducts.forEach(up => map.set(up.id, up));
      return Array.from(map.values());
    });
  };

  const handleBulkUpdateApi = async (payload: BulkUpdatePayload): Promise<boolean> => {
    const token = localStorage.getItem('admin_token');
    if (!token) return false;
    try {
      const response = await fetch('/api/products/bulk-update', {
        method: 'POST',
        headers: apiAuthHeaders(),
        body: JSON.stringify(payload),
      });
      if (!response.ok) return false;
      const data = await response.json();
      if (Array.isArray(data.products)) setProducts(data.products);
      return true;
    } catch (err) {
      console.error('Bulk update products error:', err);
      return false;
    }
  };

  const handleSyncItemVariants = async (itemId: string): Promise<Product[] | null> => {
    const token = localStorage.getItem('admin_token');
    if (!token) throw new Error('Chưa đăng nhập');

    const shopeeShop = settings.shops?.find(s => s.platform === 'shopee' && s.connected);
    const response = await fetch('/api/shopee/products/sync-item-variants', {
      method: 'POST',
      headers: apiAuthHeaders(),
      body: JSON.stringify({ itemId, shopId: shopeeShop?.shopId }),
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data?.message || data?.error || 'Tải SKU phân loại thất bại');
    }
    if (Array.isArray(data.products)) {
      setProducts(data.products);
      return data.products;
    }
    await fetchProducts();
    return null;
  };

  const handleBulkSaveProducts = async (updates: BulkSaveProductUpdate[]): Promise<boolean> => {
    const token = localStorage.getItem('admin_token');
    if (!token) return false;

    try {
      const response = await fetch('/api/products/bulk-save', {
        method: 'POST',
        headers: apiAuthHeaders(),
        body: JSON.stringify({ updates }),
      });
      if (!response.ok) return false;
      const data = await response.json();
      if (Array.isArray(data.products)) {
        setProducts(data.products);
      }
      return true;
    } catch (err) {
      console.error('Bulk save products error:', err);
      return false;
    }
  };

  const handleReplaceProducts = async (newProducts: Product[]) => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      try {
        const response = await fetch('/api/products/replace', {
          method: 'PUT',
          headers: apiAuthHeaders(),
          body: JSON.stringify({ products: newProducts }),
        });
        if (response.ok) {
          const data = await response.json();
          setProducts(data.products || newProducts);
          return;
        }
      } catch (err) {
        console.error('Replace products error:', err);
      }
    }
    setProducts(newProducts);
  };

  const fetchExpenses = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;
    try {
      const response = await fetch('/api/expenses', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        setExpenses(await response.json());
      }
    } catch (err) {
      console.error('Fetch expenses error:', err);
    }
  };

  const handleAddExpense = async (exp: Expense) => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      try {
        const response = await fetch('/api/expenses', {
          method: 'POST',
          headers: apiAuthHeaders(),
          body: JSON.stringify(exp),
        });
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data.expenses)) {
            setExpenses(data.expenses);
            return;
          }
        }
      } catch (err) {
        console.error('Add expense error:', err);
      }
    }
    setExpenses((prev) => [exp, ...prev]);
  };

  const handleDeleteExpense = async (id: string) => {
    if (!confirm('Xóa bản ghi chi phí này?')) return;
    const token = localStorage.getItem('admin_token');
    if (token) {
      try {
        const response = await fetch(`/api/expenses/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data.expenses)) {
            setExpenses(data.expenses);
            return;
          }
        }
      } catch (err) {
        console.error('Delete expense error:', err);
      }
    }
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  const handleAddLog = (log: SyncLog) => {
    setLogs(prev => [log, ...prev]);
  };

  const handleClearLogs = () => {
    if (confirm('Xóa toàn bộ nhật ký đồng bộ hiện tại?')) {
      setLogs([]);
    }
  };

  const fetchSuppliers = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;
    try {
      const response = await fetch('/api/suppliers', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        setSuppliers(await response.json());
      }
    } catch (err) {
      console.error('Fetch suppliers error:', err);
    }
  };

  const handleAddSupplier = async (payload: {
    name: string;
    supplierCode: string;
    status: 'active' | 'inactive';
  }) => {
    const token = localStorage.getItem('admin_token');
    if (!token) return false;
    try {
      const response = await fetch('/api/suppliers', {
        method: 'POST',
        headers: apiAuthHeaders(),
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (response.ok && Array.isArray(data.suppliers)) {
        setSuppliers(data.suppliers);
        return true;
      }
      alert(data.error === 'supplier_code_duplicate'
        ? 'Mã nhà cung cấp đã tồn tại!'
        : 'Tạo nhà cung cấp thất bại.');
      return false;
    } catch (err) {
      console.error('Add supplier error:', err);
      return false;
    }
  };

  const handleUpdateSupplier = async (updated: Supplier) => {
    const token = localStorage.getItem('admin_token');
    if (!token) return false;
    try {
      const response = await fetch(`/api/suppliers/${encodeURIComponent(updated.id)}`, {
        method: 'PUT',
        headers: apiAuthHeaders(),
        body: JSON.stringify(updated),
      });
      const data = await response.json();
      if (response.ok && Array.isArray(data.suppliers)) {
        setSuppliers(data.suppliers);
        return true;
      }
      alert(data.error === 'supplier_code_duplicate'
        ? 'Mã nhà cung cấp đã tồn tại!'
        : 'Cập nhật nhà cung cấp thất bại.');
      return false;
    } catch (err) {
      console.error('Update supplier error:', err);
      return false;
    }
  };

  const handleDeleteSupplier = async (id: string) => {
    const token = localStorage.getItem('admin_token');
    if (!token) return false;
    try {
      const response = await fetch(`/api/suppliers/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: apiAuthHeaders(),
      });
      const data = await response.json();
      if (response.ok && Array.isArray(data.suppliers)) {
        setSuppliers(data.suppliers);
        return true;
      }
      if (data.error === 'supplier_has_debt') {
        alert('Không thể xóa nhà cung cấp này vì vẫn đang còn công nợ chưa tất toán!');
      }
      return false;
    } catch (err) {
      console.error('Delete supplier error:', err);
      return false;
    }
  };

  const fetchImports = async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;
    try {
      const response = await fetch('/api/imports', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        setImports(await response.json());
      }
    } catch (err) {
      console.error('Fetch imports error:', err);
    }
  };

  useEffect(() => {
    if (!isAuthenticated) return;

    const bootstrapCatalog = async () => {
      purgeLegacyCatalogCache();

      const cached = await loadOrdersCache();
      if (cached.length) setOrders(cached);

      if (safeGetItem(CATALOG_PURGE_FLAG) !== '1') {
        try {
          const res = await fetch('/api/catalog/wipe-all', {
            method: 'POST',
            headers: apiAuthHeaders(),
          });
          if (res.ok) {
            safeSetItem(CATALOG_PURGE_FLAG, '1');
          }
        } catch (err) {
          console.warn('[Catalog] wipe-all skipped:', err);
        }
        purgeLegacyCatalogCache();
      }

      fetchOrders();
      fetchProducts();
      fetchSuppliers();
      fetchImports();
      fetchExpenses();
      fetchChannelSettings();
      syncShopeeOAuthShopIds();
    };

    const syncShopeeOAuthShopIds = async () => {
      const token = localStorage.getItem('admin_token');
      if (!token) return;
      try {
        const res = await fetch('/api/shopee/oauth-shops', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) return;
        const data = await res.json();
        const shopIds: string[] = Array.isArray(data.shopIds) ? data.shopIds.map(String) : [];
        if (!shopIds.length) return;

        setSettings((prev) => {
          const shops = [...(prev.shops || [])];
          const shopeeShops = shops.filter((s) => s.platform === 'shopee');
          const unmatchedTokens = shopIds.filter(
            (id) => !shopeeShops.some((s) => String(s.shopId) === id),
          );
          const unmatchedShops = shopeeShops.filter(
            (s) => !shopIds.includes(String(s.shopId)),
          );
          if (unmatchedTokens.length === 1 && unmatchedShops.length === 1) {
            const target = unmatchedShops[0];
            return {
              ...prev,
              shops: shops.map((s) =>
                s.id === target.id
                  ? {
                      ...s,
                      shopId: unmatchedTokens[0],
                      connected: true,
                      lastSynced: new Date().toISOString(),
                    }
                  : s,
              ),
            };
          }
          return prev;
        });
      } catch {
        /* ignore */
      }
    };

    void bootstrapCatalog();
  }, [isAuthenticated]);

  const handleAddImport = async (transaction: ImportTransaction) => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      try {
        const response = await fetch('/api/imports', {
          method: 'POST',
          headers: apiAuthHeaders(),
          body: JSON.stringify(transaction),
        });
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data.imports)) {
            setImports(data.imports);
          } else {
            setImports((prev) => [transaction, ...prev]);
          }
        }
      } catch (err) {
        console.error('Save import error:', err);
        setImports((prev) => [transaction, ...prev]);
      }
    } else {
      setImports((prev) => [transaction, ...prev]);
    }

    setProducts(prevProducts => prevProducts.map(p => {
      if (p.id === transaction.productId) {
        return {
          ...p,
          stock: p.stock + transaction.quantity,
          importPrice: transaction.newImportPrice,
          status: 'active' as const
        };
      }
      return p;
    }));

    const supplier = suppliers.find(s => s.id === transaction.supplierId);
    if (supplier) {
      await handleUpdateSupplier({
        ...supplier,
        totalOrderValue: supplier.totalOrderValue + transaction.totalAmount,
        totalPaid: supplier.totalPaid + transaction.paidAmount,
        totalDebt: supplier.totalDebt + (transaction.totalAmount - transaction.paidAmount),
      });
    }

    handleAddLog({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      channel: 'all',
      type: 'stock_sync',
      status: 'success',
      message: `Đã nhập sỉ thành công ${transaction.quantity} cái [${transaction.productTitle}] từ ${transaction.supplierName}.`
    });
  };

  const handleEditProductShortcut = (productId: string) => {
    setHighlightProductId(productId);
    setActiveTab('products');
  };

  const handleNavigateToImport = (productId: string) => {
    setImportPrefillProductId(productId);
    setActiveTab('imports');
    setMobileDrawerOpen(false);
  };

  const navigateTab = (tab: string, opts?: { openScanner?: boolean }) => {
    setActiveTab(tab);
    setMobileDrawerOpen(false);
    setFocusScanner(tab === 'orders' && Boolean(opts?.openScanner));

    if (tab === 'picking') {
      window.history.pushState({ tab: 'picking' }, '', '/picking');
    } else if (window.location.pathname.replace(/\/$/, '') === '/picking') {
      window.history.pushState({ tab }, '', '/');
    }
  };

  const navButtonClass = (tab: string) =>
    `w-full flex items-center gap-3 px-4 py-3 min-h-11 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
      activeTab === tab
        ? 'bg-blue-600 text-white font-extrabold shadow-sm'
        : 'hover:bg-slate-800 hover:text-white text-slate-400'
    }`;

  if (authChecking) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
        <p className="text-slate-400 text-xs mt-4 font-bold tracking-wider uppercase font-sans">Đang kiểm tra bảo mật...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-gray-50/50 md:flex md:flex-row antialiased font-sans text-gray-900 selection:bg-blue-100 selection:text-blue-900">
      {/* Sidebar Navigation */}
      <aside className="sidebar-panel max-md:hidden md:flex md:w-64 md:flex-col shrink-0 sticky top-0 h-screen overflow-y-auto bg-slate-900 text-slate-300 border-r border-slate-800" id="sidebar-panel">
        {/* Brand Header */}
        <div className="p-6 border-b border-slate-800 shrink-0">
          <BrandHeader logoSize={48} />
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto" id="sidebar-nav">
          <button
            onClick={() => navigateTab('dashboard')}
            className={navButtonClass('dashboard')}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" /> Tổng quan
          </button>

          <button
            onClick={() => navigateTab('products')}
            className={navButtonClass('products')}
          >
            <Package className="w-4 h-4 shrink-0" /> Kho & Sản phẩm
          </button>

          <button
            onClick={() => navigateTab('publish')}
            className={navButtonClass('publish')}
          >
            <Globe className="w-4 h-4 shrink-0" /> Đăng bán sỉ đa sàn
          </button>

          <button
            onClick={() => navigateTab('orders')}
            className={navButtonClass('orders')}
          >
            <ClipboardList className="w-4 h-4 shrink-0" /> Quản lý đơn hàng
          </button>

          <button
            onClick={() => navigateTab('picking')}
            className={`${navButtonClass('picking')} max-md:hidden`}
          >
            <ScanLine className="w-4 h-4 shrink-0" /> Nhặt hàng
          </button>

          <button
            onClick={() => navigateTab('bulk')}
            className={navButtonClass('bulk')}
          >
            <Sparkles className="w-4 h-4 shrink-0" /> Sửa hàng loạt & AI
          </button>

          <button
            onClick={() => navigateTab('suppliers')}
            className={navButtonClass('suppliers')}
          >
            <Users className="w-4 h-4 shrink-0" /> Nhà Cung Cấp
          </button>

          <button
            onClick={() => navigateTab('imports')}
            className={navButtonClass('imports')}
          >
            <ArrowDownToLine className="w-4 h-4 shrink-0" /> Nhập Hàng
          </button>

          <button
            onClick={() => navigateTab('financials')}
            className={navButtonClass('financials')}
          >
            <Coins className="w-4 h-4 shrink-0" /> Chi Phí Bán Hàng
          </button>

          <button
            onClick={() => navigateTab('settings')}
            className={navButtonClass('settings')}
          >
            <Settings className="w-4 h-4 shrink-0" /> Cấu hình & Kết nối
          </button>

          <button
            onClick={() => {
              setMobileDrawerOpen(false);
              handleLogout();
            }}
            className="w-full flex items-center gap-3 px-4 py-3 min-h-11 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer hover:bg-rose-950/40 hover:text-rose-400 text-slate-400 mt-4 border border-dashed border-slate-800/80 hover:border-rose-900/40"
          >
            <LogOut className="w-4 h-4 shrink-0 text-rose-500" /> Đăng xuất ({adminUser})
          </button>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-slate-800 text-center space-y-1.5 text-[10px] text-slate-500 font-medium shrink-0">
          <p>{APP_TITLE}</p>
          <p>© 2026 Linh Kiện Âm Thanh</p>
        </div>
      </aside>

      {/* Mobile drawer navigation */}
      {mobileDrawerOpen && (
        <>
          <button
            type="button"
            className="fixed inset-0 bg-black/50 z-60 md:hidden"
            aria-label="Đóng menu"
            onClick={() => setMobileDrawerOpen(false)}
          />
          <aside className="fixed inset-y-0 left-0 w-[min(100vw-3rem,18rem)] z-70 md:hidden flex flex-col bg-slate-900 text-slate-300 border-r border-slate-800 shadow-2xl">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between gap-3">
              <BrandHeader />
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(false)}
                className="min-h-11 min-w-11 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
                aria-label="Đóng menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
              <button onClick={() => navigateTab('dashboard')} className={navButtonClass('dashboard')}>
                <LayoutDashboard className="w-4 h-4 shrink-0" /> Tổng quan
              </button>
              <button onClick={() => navigateTab('products')} className={navButtonClass('products')}>
                <Package className="w-4 h-4 shrink-0" /> Kho & Sản phẩm
              </button>
              <button onClick={() => navigateTab('publish')} className={navButtonClass('publish')}>
                <Globe className="w-4 h-4 shrink-0" /> Đăng bán sỉ đa sàn
              </button>
              <button onClick={() => navigateTab('orders')} className={navButtonClass('orders')}>
                <ClipboardList className="w-4 h-4 shrink-0" /> Quản lý đơn hàng
              </button>
              <button onClick={() => navigateTab('orders', { openScanner: true })} className={`w-full flex items-center gap-3 px-4 py-3 min-h-11 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${activeTab === 'orders' && focusScanner ? 'bg-blue-600 text-white' : 'hover:bg-slate-800 hover:text-white text-slate-400'}`}>
                <Barcode className="w-4 h-4 shrink-0" /> Quét mã vạch
              </button>
              <button onClick={() => navigateTab('bulk')} className={navButtonClass('bulk')}>
                <Sparkles className="w-4 h-4 shrink-0" /> Sửa hàng loạt & AI
              </button>
              <button onClick={() => navigateTab('suppliers')} className={navButtonClass('suppliers')}>
                <Users className="w-4 h-4 shrink-0" /> Nhà Cung Cấp
              </button>
              <button onClick={() => navigateTab('imports')} className={navButtonClass('imports')}>
                <ArrowDownToLine className="w-4 h-4 shrink-0" /> Nhập Hàng
              </button>
              <button onClick={() => navigateTab('financials')} className={navButtonClass('financials')}>
                <Coins className="w-4 h-4 shrink-0" /> Chi Phí Bán Hàng
              </button>
              <button onClick={() => navigateTab('settings')} className={navButtonClass('settings')}>
                <Settings className="w-4 h-4 shrink-0" /> Cấu hình & Kết nối
              </button>
              <button
                onClick={() => {
                  setMobileDrawerOpen(false);
                  handleLogout();
                }}
                className="w-full flex items-center gap-3 px-4 py-3 min-h-11 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer hover:bg-rose-950/40 hover:text-rose-400 text-slate-400 mt-4 border border-dashed border-slate-800/80"
              >
                <LogOut className="w-4 h-4 shrink-0 text-rose-500" /> Đăng xuất
              </button>
            </nav>
          </aside>
        </>
      )}

      {/* Main Content Area */}
      <main className="md:flex-1 min-w-0 w-full">
        {/* Header toolbar */}
        <header className={`bg-white border-b border-gray-100 shadow-xs shrink-0 ${focusScanner ? 'max-md:hidden md:flex' : 'flex'}`}>
          <div className="app-main-container w-full px-4 md:px-6 py-3 md:py-4 flex items-center justify-between gap-3">
          <button
            type="button"
            className="md:hidden shrink-0 min-h-11 min-w-11 app-touch-target flex items-center justify-center rounded-xl border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 active:bg-gray-100"
            onClick={() => setMobileDrawerOpen(true)}
            aria-label="Mở menu điều hướng"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="md:hidden shrink-0">
            <NewOrderAlertButton authHeaders={apiAuthHeaders} onNewOrders={() => void fetchOrders()} />
          </div>
          <div className="md:hidden shrink-0">
            <BrandLogo size={36} className="rounded-lg" />
          </div>
          <div className={`flex-1 min-w-0 ${activeTab === 'picking' || activeTab === 'products' ? 'max-md:hidden' : ''}`}>
            <h2 className={`text-lg font-extrabold text-gray-900 tracking-tight ${activeTab === 'orders' ? 'om-orders-mobile-hide-page-title' : ''}`}>
              {activeTab === 'dashboard' && 'Bảng Điều Khiển Tổng Quan'}
              {activeTab === 'products' && 'Quản Lý Danh Sách Sản Phẩm'}
              {activeTab === 'publish' && 'Hệ Thống Đăng Bán Sản Phẩm Đa Kênh'}
              {activeTab === 'orders' && 'Hệ Thống Quản Lý Đơn Hàng Đa Sàn'}
              {activeTab === 'picking' && 'Nhặt Hàng (Picking)'}
              {activeTab === 'bulk' && 'Chỉnh Sửa Hàng Loạt & Công Cụ AI'}
              {activeTab === 'suppliers' && 'Quản Lý Đối Tác Nhà Cung Cấp'}
              {activeTab === 'imports' && 'Quản Lý Nhập Hàng'}
              {activeTab === 'financials' && 'Chi Phí Bán Hàng'}
              {activeTab === 'settings' && 'Thiết Lập API Sàn Thương Mại'}
            </h2>
            {activeTab !== 'dashboard' && (
            <p className={`text-xs text-gray-400 ${activeTab === 'orders' ? 'om-orders-mobile-hide-page-desc' : ''}`}>
              {activeTab === 'products' && 'Quản lý giá nhập, giá bán lẻ, tồn kho và xuất bản kênh.'}
              {activeTab === 'publish' && 'Đăng bán sản phẩm lên nhiều gian hàng đồng thời, lồng khung hình sỉ hàng loạt và tối ưu tiêu đề chống spam bằng AI.'}
              {activeTab === 'orders' && 'Quản lý 8 trạng thái đơn Shopee & TikTok, chuẩn bị hàng đóng gói và in vận đơn nhiệt.'}
              {activeTab === 'picking' && 'Quét mã đơn, tích sản phẩm đã nhặt và chuyển sang đóng gói.'}
              {activeTab === 'bulk' && 'Tăng giảm giá %, đặt tồn kho, tối ưu nội dung bằng AI hàng loạt.'}
              {activeTab === 'suppliers' && 'Quản lý thông tin liên hệ, công nợ sỉ và tiền độ thanh toán cho xưởng sỉ.'}
              {activeTab === 'imports' && 'Quản lý hóa đơn nhập đầu vào, theo dõi biến động % giá nhập hàng.'}
              {activeTab === 'financials' && 'Theo dõi chi phí hoạt động, cơ cấu quỹ và mô phỏng lợi nhuận sau phí sàn.'}
              {activeTab === 'settings' && 'Cập nhật mã gian hàng, API key và trỏ DNS về hosting riêng.'}
            </p>
            )}
          </div>

          <div className="max-md:hidden md:flex items-center gap-4 text-xs font-semibold shrink-0">
            <NewOrderAlertButton authHeaders={apiAuthHeaders} onNewOrders={() => void fetchOrders()} />

            {/* Shopee Connection badge */}
            <div className="flex items-center gap-1.5 bg-gray-50 border border-gray-100 px-3 py-1.5 rounded-xl">
              <span className={`w-2 h-2 rounded-full ${settings.shopeeConnected ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
              <span className="text-gray-600">Shopee</span>
            </div>

            {/* TikTok Connection badge */}
            <div className="flex items-center gap-1.5 bg-gray-50 border border-gray-100 px-3 py-1.5 rounded-xl">
              <span className={`w-2 h-2 rounded-full ${settings.tiktokConnected ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
              <span className="text-gray-600">TikTok Shop</span>
            </div>
          </div>
          </div>
        </header>

        {/* Active Tab rendering */}
        <div className={`app-main-container app-page-content app-scroll-list ${activeTab === 'picking' ? 'max-md:pt-1 max-md:px-2' : activeTab === 'products' ? 'max-md:pt-1 max-md:px-2' : 'max-md:pt-2 max-md:px-3'} p-4 md:p-6 pb-24 md:pb-6`}>
          {activeTab === 'dashboard' && (
            <ErrorBoundary label="Tổng quan">
              <Dashboard
                orders={orders}
                products={products}
                onTabChange={setActiveTab}
                onEditProductShortcut={handleEditProductShortcut}
                onUpdateProduct={handleUpdateProduct}
                onNavigateToImport={handleNavigateToImport}
                onRefreshProducts={fetchProducts}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'products' && (
            <>
              <div className="max-md:block md:hidden">
                <InventoryAudit
                  products={products}
                  shopId={settings.shops?.find((s) => s.platform === 'shopee' && s.connected)?.shopId}
                  onRefreshProducts={fetchProducts}
                />
              </div>
              <div className="max-md:hidden md:block">
                <ProductList
                  products={products}
                  onAddProduct={handleAddProduct}
                  onUpdateProduct={handleUpdateProduct}
                  onDeleteProduct={handleDeleteProduct}
                  onReplaceProducts={handleReplaceProducts}
                  onBulkSave={handleBulkSaveProducts}
                  onSyncItemVariants={handleSyncItemVariants}
                  onRefreshProducts={fetchProducts}
                  onProductsUpdated={(prods) => setProducts(prods)}
                  onBulkSelect={setSelectedIds}
                  selectedIds={selectedIds}
                  onTabChange={setActiveTab}
                  highlightProductId={highlightProductId}
                  onClearHighlight={() => setHighlightProductId(null)}
                  shops={settings.shops || []}
                  suppliers={suppliers}
                  onAddLog={handleAddLog}
                  productsLoading={productsLoading}
                />
              </div>
            </>
          )}

          {activeTab === 'publish' && (
            <PublishManager 
              products={products}
              onUpdateProduct={handleUpdateProduct}
              onAddLog={handleAddLog}
              shops={settings.shops || []}
            />
          )}

          {activeTab === 'picking' && (
            <OrderPicking
              orders={orders}
              onUpdateOrders={handleUpdateOrders}
              onAddLog={handleAddLog}
            />
          )}

          {activeTab === 'orders' && (
            <ErrorBoundary label="Quản lý đơn hàng">
              <OrderManager 
              orders={orders}
              onUpdateOrders={handleUpdateOrders}
              onRefreshOrders={pullOrders}
              onFetchOrders={fetchOrders}
              ordersLoading={ordersLoading}
              shops={settings.shops || []}
              onAddLog={handleAddLog}
              products={products}
              onUpdateProduct={handleUpdateProduct}
              focusScanner={focusScanner}
              onCloseScanner={() => setFocusScanner(false)}
              onEndScanSession={() => setFocusScanner(false)}
            />
            </ErrorBoundary>
          )}

          {activeTab === 'bulk' && (
            <BulkEditor 
              products={products}
              selectedIds={selectedIds}
              shops={settings.shops || []}
              onUpdateBulk={handleUpdateBulk}
              onBulkUpdate={handleBulkUpdateApi}
              onAddLog={handleAddLog}
            />
          )}

          {activeTab === 'suppliers' && (
            <SupplierManager 
              suppliers={suppliers}
              onAddSupplier={handleAddSupplier}
              onUpdateSupplier={handleUpdateSupplier}
              onDeleteSupplier={handleDeleteSupplier}
            />
          )}

          {activeTab === 'imports' && (
            <ImportManager 
              imports={imports}
              suppliers={suppliers}
              onRefreshSuppliers={fetchSuppliers}
              onSuppliersUpdated={setSuppliers}
              products={products}
              onAddImport={handleAddImport}
              onEditProductShortcut={handleEditProductShortcut}
              initialProductId={importPrefillProductId}
              onInitialProductConsumed={() => setImportPrefillProductId(null)}
            />
          )}

          {activeTab === 'financials' && (
            <Financials 
              expenses={expenses}
              products={products}
              orders={orders}
              onAddExpense={handleAddExpense}
              onDeleteExpense={handleDeleteExpense}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView 
              settings={settings}
              onUpdateSettings={persistChannelSettings}
              logs={logs}
              onClearLogs={handleClearLogs}
            />
          )}
        </div>
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <div className={`fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 z-50 max-md:flex md:hidden items-stretch justify-between py-1.5 px-1 shadow-xl safe-area-pb ${focusScanner ? 'max-md:hidden' : ''}`}>
        <button
          onClick={() => navigateTab('products')}
          type="button"
          className={`flex flex-1 flex-col items-center justify-center gap-0.5 min-h-12 px-1 py-2 app-touch-target cursor-pointer transition-all ${
            activeTab === 'products'
              ? 'text-blue-500 font-extrabold'
              : 'text-slate-400 hover:text-white font-medium'
          }`}
        >
          <Scale className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wide font-extrabold">Kiểm hàng</span>
        </button>

        <button
          onClick={() => navigateTab('orders')}
          type="button"
          className={`flex flex-1 flex-col items-center justify-center gap-0.5 min-h-12 px-1 py-2 app-touch-target cursor-pointer transition-all ${
            activeTab === 'orders' && !focusScanner
              ? 'text-blue-500 font-extrabold'
              : 'text-slate-400 hover:text-white font-medium'
          }`}
        >
          <ClipboardList className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wide font-extrabold">Đơn hàng</span>
        </button>

        <button
          onClick={() => navigateTab('picking')}
          type="button"
          className={`flex flex-1 flex-col items-center justify-center gap-0.5 min-h-12 px-1 py-2 app-touch-target cursor-pointer transition-all ${
            activeTab === 'picking'
              ? 'text-emerald-400 font-extrabold'
              : 'text-slate-400 hover:text-white font-medium'
          }`}
        >
          <ShoppingBasket className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wide font-extrabold">Nhặt hàng</span>
        </button>

        <button
          onClick={() => navigateTab('orders', { openScanner: true })}
          type="button"
          className={`flex flex-1 flex-col items-center justify-center gap-0.5 min-h-12 px-1 py-2 app-touch-target cursor-pointer transition-all ${
            activeTab === 'orders' && focusScanner
              ? 'text-blue-500 font-extrabold'
              : 'text-slate-400 hover:text-white font-medium'
          }`}
        >
          <Barcode className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wide font-extrabold">Quét mã</span>
        </button>
      </div>
    </div>
  );
}
